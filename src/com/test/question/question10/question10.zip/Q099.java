package com.test.question;

public class Q099 {

	public static void main(String[] args) {
//		출력..
//		00:00:00 //t1.info();
//		02:30:45 //t2.info();
//		02:10:30 //t3.info();
//		00:30:10 //t4.info();
//		01:30:10 //t5.info();
//		00:00:50 //t6.info();
//		02:46:40 //t7.info();
		Time t1 = new Time(); //기본 생성자 호출
		System.out.println(t1.info());

		//시간 2
		Time t2 = new Time(2, 30, 45); //오버로딩 생성자 호출
		System.out.println(t2.info());

		//시간 3
		Time t3 = new Time(1, 70, 30); //오버로딩 생성자 호출
		System.out.println(t3.info());

		//시간 4
		Time t4 = new Time(30, 10); //오버로딩 생성자 호출
		System.out.println(t4.info());

		//시간 5
		Time t5 = new Time(90, 10); //오버로딩 생성자 호출
		System.out.println(t5.info());

		//시간 6
		Time t6 = new Time(50); //오버로딩 생성자 호출
		System.out.println(t6.info());

		//시간 7
		Time t7 = new Time(10000); //오버로딩 생성자 호출
		System.out.println(t7.info());

	}

}
