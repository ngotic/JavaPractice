package com.test.question;

public class Q096 {

	public static void main(String[] args) {
		Box box1 = new Box();
		
		box1.cook();
		box1.check();
		box1.list();
		
	}

}
